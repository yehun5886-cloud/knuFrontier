# 🎨 프롬프트 엔지니어링 워크숍 포트폴리오

> Stable Diffusion AI를 활용한 이미지 생성 실습 결과물

## 👤 수강생 정보

| 항목 | 내용 |
|------|------|
| **이름** | 김예훈 |
| **학번** | 3399 |
| **작성일** | 2026년 01월 23일 |
| **총 작품 수** | 7개 |

---

## 📚 회차별 학습 기록

### 📖 1회차: 첫 AI 이미지 생성

**학습 기법**: 기본 프롬프팅

#### 작품 1

| 항목 | 내용 |
|------|------|
| **프롬프트** | `cute cat` |
| **네거티브** | `-` |
| **생성 시간** | 2026-01-23 05:40:29 |

![작품 1](images/session1_1.png)

> 신기해요

---

### 📖 2회차: Zero-shot vs Detail

**학습 기법**: 상세 프롬프팅

#### 작품 1

| 항목 | 내용 |
|------|------|
| **프롬프트** | `cute cat` |
| **네거티브** | `-` |
| **생성 시간** | 2026-01-23 05:48:07 |

![작품 1](images/session2_1.png)

> 자세히 설명하니까 더 그림을 잘그려요!

#### 작품 2

| 항목 | 내용 |
|------|------|
| **프롬프트** | `a fluffy orange cat sitting on a vintage armchair, warm sunlight streaming through window, photorealistic, highly detailed, 8k resolution` |
| **네거티브** | `-` |
| **생성 시간** | 2026-01-23 05:48:07 |

![작품 2](images/session2_2.png)

> 자세히 설명하니까 더 그림을 잘그려요!

---

### 📖 3회차: Persona & Style

**학습 기법**: 스타일 프롬프팅

#### 작품 1

| 항목 | 내용 |
|------|------|
| **프롬프트** | `a forest, a cute cat and dog in the house, in the style of Van Gogh, swirling brushstrokes, vibrant colors, post-impressionist` |
| **네거티브** | `-` |
| **생성 시간** | 2026-01-23 05:57:59 |

![작품 1](images/session3_1.png)

> 내가 원하는 다양한 스타일을 설정하여 내 마음대로 할수 있으니까 좋아요

---

### 📖 4회차: Negative Prompting

**학습 기법**: 네거티브 프롬프팅

#### 작품 1

| 항목 | 내용 |
|------|------|
| **프롬프트** | `a beautiful portrait of a young woman, elegant dress, garden background, soft lighting` |
| **네거티브** | `draw bad hands, extra fingers, mutated hands, poorly drawn face, mutation, deformed, ugly, trasg` |
| **생성 시간** | 2026-01-23 06:20:02 |

![작품 1](images/session4_1.png)

> 복잡한 정도를 조절하며 그림을 생성하니까 결과가 기괴하기도 하고 신기하기도 하였다.

---

### 📖 5회차: Step-back Prompting

**학습 기법**: 추상화 프롬프팅

#### 작품 1

| 항목 | 내용 |
|------|------|
| **프롬프트** | `alone` |
| **네거티브** | `blurry, low quality, distorted, text, watermark` |
| **생성 시간** | 2026-01-23 06:29:11 |

![작품 1](images/session5_1.png)

> 스텝백을 사용하여 추상적 그림을 그리게 하니까 더 자세히 기존에 설명하여 ai가 잘 알아들어 그냥 실행했을 떄 보다 자세히 그려준다.

---

### 📖 6회차: Chain of Thought

**학습 기법**: 레이어 빌딩

#### 작품 1

| 항목 | 내용 |
|------|------|
| **프롬프트** | `a robot, trigging a gun, war` |
| **네거티브** | `blurry, low quality` |
| **생성 시간** | 2026-01-23 06:35:11 |

![작품 1](images/session6_1.png)

> 각 레이어 별로 세부 설명을 붙여주니 그냥 주제 하나만 한 것보다 자세히 그려준다

---

## 🏆 Best 작품

**선택한 작품**: 

**선택 이유**: 

---

## 💡 워크숍 후기



---

## 🛠️ 사용 기술

- Stable Diffusion
- Streamlit
- Google Colab + ngrok

---

<p align="center"><i>🎓 KNU 프롬프트 엔지니어링 워크숍 수료</i></p>
